'use strict';

function DirectionSpisokCtrl($scope, $location, Direction) {
	//
	$scope.list = Direction.query();
	$scope.query_add = ""

	$scope.Add = function() {
		//
		if($scope.query_add!=""){	
			Direction.create($scope.query_add, function(){ $scope.list = Direction.query(); });
		}
		$scope.query_add = ""
	};

	$scope.Del = function(id) {
		//
		Direction.rem({id:id}, function(){ $scope.list = Direction.query();})
	};

}

function DirectionEditCtrl ($scope, $routeParams, $location, Direction) {
	// body...
	$scope.item = Direction.get({id:$routeParams.id})

	$scope.save = function() {
		//
		$scope.item.$save({id:$routeParams.id},  function(){ $location.path('/direction'); })
	};
}

function TaskSpisokLabelCtrl ($scope, $routeParams, $location, Tasks_Label, Direction, Task) {
	// body...
	$scope.list = Tasks_Label.query();
	$scope.Direction_list = Direction.query();

	$scope.query_add = ""
	$scope.query_add_time = "1h"
	$scope.direction_id = -1

	$scope.set_label = function(id) {
		//
		var user = Task.get({id:id}, function() {
			if(user.Label){
				user.Label = false;
			}else{
				user.Label = true;
			}
			
			user.$save({id:id});
			$scope.list = Tasks_Label.query();
		});		
	};

	$scope.Add = function() {
		//
		if($scope.query_add!=""){	
			var id = "0";
			if (typeof $routeParams.id === "undefined"){
				id = "0"
			}
			else{
				id = $routeParams.id
			}
			console.log(id, $routeParams.id)
			Task.create({name:$scope.query_add, 
							direction_id:parseInt(id), 
							duration:$scope.query_add_time, label:true}, function(){ $scope.list = Tasks_Label.query(); });
			$scope.query_add = ""
			$scope.query_add_time = "1h"
		}
	};

	$scope.Del = function(id) {
		//
		Task.rem({id:id}, function(){ $scope.list = Tasks_Label.query();})
	};
}

function TaskSpisokAllCtrl ($scope, $routeParams, $location, Task, Direction) {
	// body...
	$scope.list = Task.query();
	$scope.Direction_list = Direction.query();

	$scope.query_add = ""
	$scope.direction_id = 0

	$scope.query_add_time = "1h"

	$scope.set_label = function(id) {
		//
		var user = Task.get({id:id}, function() {
			if(user.Label){
				user.Label = false;
			}else{
				user.Label = true;
			}
			
			user.$save({id:id});
			$scope.list = Task.query();
		});		
	};

	$scope.Add = function() {
		//
		if($scope.query_add!=""){	
			var id = "0";
			if (typeof $routeParams.id === "undefined"){
				id = "0"
			}
			else{
				id = $routeParams.id
			}
			console.log(id, $routeParams.id)
			Task.create({name:$scope.query_add, 
							direction_id:parseInt(id), 
							duration:$scope.query_add_time, label:false}, function(){ $scope.list = Task.query(); });
			$scope.query_add = ""
			$scope.query_add_time = "1h"
		}
	};

	$scope.Del = function(id) {
		//
		Task.rem({id:id}, function(){ $scope.list = Task.query();})
	};

}

function TaskSpisokDirectionCtrl ($scope, $routeParams, $location, Direction, Task, Tasks_Direction) {
	// body...
	$scope.list = Tasks_Direction.query({id:$routeParams.id});
	$scope.Direction_list = Direction.query();

	$scope.direction_id = $routeParams.id

	$scope.query_add_time = "1h"

	$scope.completed = function(id) {
		//
		console.log(id)
		var user = Task.get({id:id}, function() {
			console.log(user.completed)
			if(user.completed){
				user.completed = false;
			}else{
				user.completed = true;
			}
			console.log(user)
			user.$save({id:id});
			//$scope.list = Tasks_Direction.query({id:$routeParams.id});
		});	
	};

	$scope.set_label = function(id) {
		//
		var user = Task.get({id:id}, function() {
			if(user.Label){
				user.Label = false;
			}else{
				user.Label = true;
			}
			
			user.$save({id:id});
			$scope.list = Tasks_Direction.query({id:$routeParams.id});
		});		
	};

	$scope.Add = function() {
		//
		if($scope.query_add!=""){	
			var id = "0";
			if (typeof $routeParams.id === "undefined"){
				id = "0"
			}
			else{
				id = $routeParams.id
			}
			console.log(id, $routeParams.id)
			Task.create({name:$scope.query_add, 
							direction_id:parseInt(id), 
							duration:$scope.query_add_time, label:false}, function(){ $scope.list = Tasks_Direction.query({id:$routeParams.id}); });
			$scope.query_add = ""
			$scope.query_add_time = "1h"
		}
	};


	$scope.Del = function(id) {
		//
		Task.rem({id:id}, function(){ $scope.list = Tasks_Direction.query({id:$routeParams.id});})
	};
}

function TaskEditCtrl ($scope, $location, Task, $routeParams) {
	// body...
	$scope.item = Task.get({id:$routeParams.id})

	$scope.save = function() {
		//
		$scope.item.$save({id:$routeParams.id},  function(){ $location.path('/task'); })
	};
}