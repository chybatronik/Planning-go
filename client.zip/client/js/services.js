'use strict';

angular.module('admin.services', ['ngResource'])
  .factory('Direction', function($resource){
    return $resource('direction/:id/:action', {}, {
      create: {method:'PUT'},
      rem: {method:'DELETE'},
      saveData: {method:'POST'},
      toggle: {method:'GET', params:{action:'toggle'}}
    })})
  .factory('Task', function($resource){
    return $resource('task/:id/:action', {}, {
      create: {method:'PUT'},
      rem: {method:'DELETE'},
      saveData: {method:'POST'},
      toggle: {method:'GET', params:{action:'toggle'}}
    });
  })
  .factory('Tasks_Direction', function($resource){
    return $resource('task/direction/:id/:action', {}, {
      create: {method:'PUT'},
      rem: {method:'DELETE'},
      saveData: {method:'POST'},
      toggle: {method:'GET', params:{action:'toggle'}}
    });
  })
.factory('Tasks_Label', function($resource){
    return $resource('task/label/:id/:action', {}, {
      create: {method:'PUT'},
      rem: {method:'DELETE'},
      saveData: {method:'POST'},
      toggle: {method:'GET', params:{action:'toggle'}}
    });
  });